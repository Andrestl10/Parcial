#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char *argv[]) {
    if (argc != 3) {
        printf("Uso: %s <archivo> <palabra_clave>\n", argv[0]);
        return 1;
    }

    FILE *archivo = fopen(argv[1], "r");
    if (archivo == NULL) {
        printf("Error al abrir el archivo.\n");
        return 1;
    }

    char *palabra_clave = argv[2];
    char buffer[1000];
    int contador = 0;
    
    while (fscanf(archivo, "%s", buffer) != EOF) {
        if (strcmp(buffer, palabra_clave) == 0) {
            contador++;
        }
    }

    fclose(archivo);

    printf("La palabra '%s' se repite %d veces en el texto.\n", palabra_clave, contador);

    return 0;
}
