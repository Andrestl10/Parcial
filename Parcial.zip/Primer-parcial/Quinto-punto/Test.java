import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.tree.*;

import java.io.FileInputStream;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

public class Test {
    public static void main(String[] args) throws Exception {
        String inputFile = args.length > 0 ? args[0] : null;
        InputStream is = System.in;
        if (inputFile != null) is = new FileInputStream(inputFile);
        
        CharStream input = CharStreams.fromStream(is);
        TrigLexer lexer = new TrigLexer(input);
        CommonTokenStream tokens = new CommonTokenStream(lexer);
        TrigParser parser = new TrigParser(tokens);
        ParseTree tree = parser.expr(); // Inicia el análisis

        TrigVisitorImpl eval = new TrigVisitorImpl();
        System.out.println(eval.visit(tree));
    }
}

class TrigVisitorImpl extends TrigBaseVisitor<Double> {

    @Override
    public Double visitExpr(TrigParser.ExprContext ctx) {
        String func = ctx.func().getText();
        int value = Integer.parseInt(ctx.INT().getText());

        // Convertir grados a radianes
        double radians = Math.toRadians(value);

        switch (func) {
            case "Sin":
                return Math.sin(radians);
            case "Cos":
                return Math.cos(radians);
            case "Tan":
                return Math.tan(radians);
            default:
                throw new RuntimeException("Función no soportada: " + func);
        }
    }
}
